{pkgs}: {
  deps = [
    pkgs.flutter
  ];
}
